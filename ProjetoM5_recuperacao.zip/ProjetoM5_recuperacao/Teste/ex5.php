<?php

$maior=-99999;
$menor=99999;
$soma=0;
$produto=1;


$numeros = array();
for ($i=0;$i<15;$i++){
	$numeros[]=rand(1,1000);
}

foreach ($numeros as $numero){
	if($numero>$maior){
		$maior=$numero;
	}
	if($numero<$menor){
		$menor=$numero;
	}


$soma=$soma+$numero;
$produto=$produto*$numero;

}
$media=$soma/15;

echo "Nº Maior:" .$maior;
echo "<br>";
echo "Nº Menor:" .$menor;
echo "<br>";
echo "Média:" .$media;
echo "<br>";
echo "Produto:" .$produto;
echo "<br>";

?>