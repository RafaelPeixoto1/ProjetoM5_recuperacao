<?php

$a=0;
$b=0;
$soma=0;

function adicionar($a, $b){
	return $a+$b;
}
$soma=adicionar (1,5);

echo "A soma é:" .$soma;

?>
