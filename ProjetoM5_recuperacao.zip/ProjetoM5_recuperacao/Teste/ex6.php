<?php




$dias = array('domingo','segunda','terca','quarta','quinta','sexta','sabado');

//echo $dias[0];//domingo
//echo $dias[1];//segunda
//echo $dias[2];//terça
//echo $dias[3];//quarta
//echo $dias[4];//quinta
//echo $dias[5];//sexta
echo  $dias[6];//sabado
echo '<br>';

$meses = array('Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro');

echo $meses[0];//Janeiro
//echo $meses[1];//Fevereiro
//echo $meses[2];//Março
//echo $meses[3];//Abril
//echo $meses[4];//Maio
//echo $meses[5];//Junho
//echo  $meses[6];//Julho
//echo  $meses[7];//Agosto
//echo  $meses[8];//Setembro
//echo  $meses[9];//Outubro
//echo  $meses[10];//Novembro
//echo  $meses[11];//Dezembro


?>