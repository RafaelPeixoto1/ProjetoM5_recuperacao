<?php

$dias = array('domingo','segunda','terca','quarta','quinta','sexta','sabado');

//echo "0:"  .$dias[0];//domingo
//echo "1:" .$dias[1];//segunda
//echo "2:" .$dias[2];//terça
//echo "3:" .$dias[3];//quarta
//echo "4:" .$dias[4];//quinta
//echo "5:" .$dias[5];//sexta
echo  $dias[6];//sabado
