<?php

$meses =$_POST["meses"];
$dias =$_POST["dias"];





echo "Mês: ".$meses;
echo "<br>";
echo "Dia: ".$dias;
?>
